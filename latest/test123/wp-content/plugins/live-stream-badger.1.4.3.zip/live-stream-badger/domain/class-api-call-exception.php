<?php
namespace livestreambadger;

class LSB_API_Call_Exception extends \Exception {
}